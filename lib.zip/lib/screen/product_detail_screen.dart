import 'package:flutter/material.dart';
import '../cart_manager.dart';
import '../cart_screen.dart';
import '../product_model.dart';

class ProductDetailScreen extends StatefulWidget {
  final LumearProduct product;
  const ProductDetailScreen({super.key, required this.product});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  static const cream = Color(0xFFFFF8F4);
  static const maroon = Color(0xFF963B36);
  static const darkMaroon = Color(0xFF721E1E);
  static const muted = Color(0xFFC78F88);
  static const ink = Color(0xFF4E3431);

  int imageIndex = 0;
  int quantity = 1;
  final Map<String, String> selectedVariants = {};
  bool isFavorite = false;
  bool isAdding = false;

  LumearProduct get product => widget.product;

  int get availableStock {
    if (product.variants.isEmpty) return product.stock;
    int stock = product.stock;
    for (final variant in product.variants) {
      final selected = selectedVariants[variant.name];
      if (selected != null) {
        stock = stock < variant.stockFor(selected) ? stock : variant.stockFor(selected);
      } else {
        stock = stock < variant.options.map(variant.stockFor).fold<int>(0, (a, b) => a + b)
            ? stock
            : variant.options.map(variant.stockFor).fold<int>(0, (a, b) => a + b);
      }
    }
    return stock;
  }

  double get currentPrice {
    double price = product.price;
    for (final variant in product.variants) {
      final option = selectedVariants[variant.name];
      final variantPrice = option == null ? null : variant.priceFor(option);
      if (variantPrice != null) price = variantPrice;
    }
    return price;
  }

  String money(double value) => '₱${value.toStringAsFixed(2)}';

  void addToCart({bool buyNow = false}) {
    if (availableStock <= 0 || quantity > availableStock) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('The selected variant does not have enough stock.')),
      );
      return;
    }
    if (product.variants.any((v) => !selectedVariants.containsKey(v.name))) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select all product variants first.')),
      );
      return;
    }

    setState(() => isAdding = true);
    CartManager.instance.addToCart(
      productId: product.id,
      name: product.name,
      price: money(currentPrice),
      icon: product.icon,
      imageUrl: product.imageUrl,
      selectedVariants: Map<String, String>.from(selectedVariants),
      quantity: quantity,
    );

    Future.delayed(const Duration(milliseconds: 450), () {
      if (mounted) setState(() => isAdding = false);
    });

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: darkMaroon,
          content: Row(children: [
            const Icon(Icons.check_circle_rounded, color: Colors.white),
            const SizedBox(width: 10),
            Expanded(child: Text('${product.name} added to cart')),
          ]),
          action: SnackBarAction(
            label: 'VIEW CART',
            textColor: Colors.white,
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
          ),
        ),
      );

    if (buyNow) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    final gallery = product.gallery;
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(
        backgroundColor: cream,
        elevation: 0,
        iconTheme: const IconThemeData(color: darkMaroon),
        title: const Text('Product Details', style: TextStyle(color: darkMaroon, fontWeight: FontWeight.w800, fontSize: 17)),
        actions: [
          IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
            icon: const Icon(Icons.shopping_cart_outlined),
          ),
          IconButton(
            onPressed: () => setState(() => isFavorite = !isFavorite),
            icon: Icon(isFavorite ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: isFavorite ? maroon : darkMaroon),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 18),
        children: [
          Container(
            color: const Color(0xFFF4E9E4),
            height: 350,
            child: Stack(children: [
              PageView.builder(
                itemCount: gallery.length,
                onPageChanged: (i) => setState(() => imageIndex = i),
                itemBuilder: (_, i) => Image.network(
                  gallery[i], fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Center(child: Icon(product.icon, size: 90, color: muted)),
                ),
              ),
              Positioned(
                left: 16, bottom: 16,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: darkMaroon.withOpacity(0.88),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.photo_library_outlined, color: Colors.white, size: 14),
                    const SizedBox(width: 6),
                    Text('${imageIndex + 1} / ${gallery.length}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
              if (product.isNew)
                Positioned(top: 16, left: 16, child: _tag('NEW ARRIVAL', maroon)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.category.toUpperCase(), style: const TextStyle(color: muted, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.1)),
              const SizedBox(height: 7),
              Text(product.name, style: const TextStyle(color: ink, fontWeight: FontWeight.bold, fontSize: 22, height: 1.2)),
              const SizedBox(height: 12),
              Row(children: [
                Text(money(currentPrice), style: const TextStyle(color: maroon, fontWeight: FontWeight.bold, fontSize: 24)),
                if (product.originalPrice != null) ...[
                  const SizedBox(width: 10),
                  Text(money(product.originalPrice!), style: const TextStyle(color: muted, decoration: TextDecoration.lineThrough, fontSize: 13)),
                  const SizedBox(width: 8),
                  _tag('SALE', const Color(0xFFB84C42)),
                  if (product.originalPrice! > 0 && product.originalPrice! > currentPrice)
                    _tag('-${(((product.originalPrice! - currentPrice) / product.originalPrice!) * 100).round()}%', const Color(0xFF2F8065)),
                ],
              ]),
              if (product.originalPrice != null && product.originalPrice! > currentPrice) ...[
                const SizedBox(height: 5),
                Text('You save ${money(product.originalPrice! - currentPrice)}', style: const TextStyle(color: Color(0xFF2F8065), fontSize: 12, fontWeight: FontWeight.w600)),
              ],
              const SizedBox(height: 13),
              Row(children: [
                const Icon(Icons.star_rounded, color: Color(0xFFE5A33D), size: 19),
                const SizedBox(width: 4),
                Text(product.rating.toStringAsFixed(1), style: const TextStyle(color: ink, fontWeight: FontWeight.bold)),
                const SizedBox(width: 7),
                Text('(${product.reviewCount} reviews)', style: const TextStyle(color: muted, fontSize: 12)),
                const SizedBox(width: 12),
                Container(width: 1, height: 15, color: muted),
                const SizedBox(width: 12),
                Text('${product.soldCount} sold', style: const TextStyle(color: ink, fontSize: 12)),
              ]),
              const SizedBox(height: 13),
              Row(children: [
                const Icon(Icons.inventory_2_outlined, size: 17, color: muted),
                const SizedBox(width: 7),
                Text(availableStock > 0 ? '$availableStock available' : 'Out of stock',
                  style: TextStyle(color: availableStock > 0 ? ink : Colors.red, fontSize: 12, fontWeight: FontWeight.w600)),
                const Spacer(),
                const Icon(Icons.local_shipping_outlined, size: 18, color: muted),
                const SizedBox(width: 6),
                const Text('COD available', style: TextStyle(color: ink, fontSize: 12)),
              ]),
            ]),
          ),
          _section(
            title: 'Choose your options',
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (product.variants.isEmpty)
                const Text('No variants required for this product.', style: TextStyle(color: muted, fontSize: 12)),
              for (final variant in product.variants) ...[
                Text(variant.name, style: const TextStyle(color: ink, fontWeight: FontWeight.bold, fontSize: 13)),
                const SizedBox(height: 9),
                Wrap(spacing: 8, runSpacing: 8, children: variant.options.map((option) {
                  final selected = selectedVariants[variant.name] == option;
                  final stock = variant.stockFor(option);
                  final disabled = stock <= 0;
                  return ChoiceChip(
                    label: Text('$option${disabled ? ' · Sold out' : ''}'),
                    selected: selected,
                    onSelected: disabled ? null : (_) => setState(() {
                      selectedVariants[variant.name] = option;
                      quantity = 1;
                    }),
                    selectedColor: const Color(0xFFF0D6D0),
                    backgroundColor: Colors.white,
                    labelStyle: TextStyle(color: disabled ? Colors.grey : selected ? darkMaroon : ink, fontWeight: selected ? FontWeight.bold : FontWeight.normal),
                    side: BorderSide(color: selected ? maroon : const Color(0xFFECDCD4)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  );
                }).toList()),
                const SizedBox(height: 16),
              ],
              Row(children: [
                const Text('Quantity', style: TextStyle(color: ink, fontWeight: FontWeight.bold, fontSize: 13)),
                const Spacer(),
                _quantityButton(Icons.remove_rounded, () { if (quantity > 1) setState(() => quantity--); }),
                SizedBox(width: 42, child: Center(child: Text('$quantity', style: const TextStyle(color: ink, fontWeight: FontWeight.bold)))),
                _quantityButton(Icons.add_rounded, () { if (quantity < availableStock) setState(() => quantity++); }),
              ]),
              const SizedBox(height: 6),
              Text('Maximum ${availableStock < 0 ? 0 : availableStock} unit(s) available for the current selection.', style: const TextStyle(color: muted, fontSize: 11)),
            ]),
          ),
          _section(
            title: 'Product description',
            child: Text(product.description, style: const TextStyle(color: ink, height: 1.6, fontSize: 13)),
          ),
          _section(
            title: 'Shop information',
            child: Row(children: [
              Container(width: 48, height: 48, decoration: const BoxDecoration(color: Color(0xFFF9EEEA), shape: BoxShape.circle), child: const Icon(Icons.storefront_rounded, color: maroon)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(product.shopName, style: const TextStyle(color: ink, fontWeight: FontWeight.bold)),
                const SizedBox(height: 3),
                const Text('Trusted Lumear seller · Demo shop profile', style: TextStyle(color: muted, fontSize: 11)),
              ])),
              OutlinedButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shop pages will be connected in a future update.'))), child: const Text('Visit')),
            ]),
          ),
          _section(
            title: 'Ratings & reviews',
            trailing: Text('${product.rating.toStringAsFixed(1)} ★', style: const TextStyle(color: maroon, fontWeight: FontWeight.bold)),
            child: product.reviews.isEmpty
                ? const Text('No reviews yet. Be the first to review this product after ordering.', style: TextStyle(color: muted, fontSize: 12))
                : Column(children: product.reviews.map((review) => Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: Color(0xFFF0E3DE)))),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        CircleAvatar(radius: 17, backgroundColor: const Color(0xFFF0DCD6), child: Text(review.reviewer.isNotEmpty ? review.reviewer[0] : '?', style: const TextStyle(color: maroon, fontWeight: FontWeight.bold))),
                        const SizedBox(width: 9),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(review.reviewer, style: const TextStyle(color: ink, fontWeight: FontWeight.bold, fontSize: 12)),
                          Text(review.date, style: const TextStyle(color: muted, fontSize: 10)),
                        ])),
                        Text('${review.rating.toStringAsFixed(1)} ★', style: const TextStyle(color: Color(0xFFE5A33D), fontWeight: FontWeight.bold, fontSize: 12)),
                      ]),
                      const SizedBox(height: 9),
                      Text(review.comment, style: const TextStyle(color: ink, height: 1.45, fontSize: 12)),
                      if (review.photoUrls.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        SizedBox(height: 70, child: ListView(scrollDirection: Axis.horizontal, children: review.photoUrls.map((url) => Padding(padding: const EdgeInsets.only(right: 8), child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(url, width: 70, height: 70, fit: BoxFit.cover)))).toList())),
                      ],
                    ]),
                  )).toList(),
          ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(14, 11, 14, 11),
          decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Color(0x14000000), blurRadius: 12, offset: Offset(0, -3))], border: Border(top: BorderSide(color: Color(0xFFECDCD4)))),
          child: Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: isAdding ? null : () => addToCart(),
              icon: AnimatedSwitcher(duration: const Duration(milliseconds: 180), child: Icon(isAdding ? Icons.check_circle_rounded : Icons.add_shopping_cart_rounded, key: ValueKey(isAdding), size: 18)),
              label: Text(isAdding ? 'Added!' : 'Add to Cart'),
              style: OutlinedButton.styleFrom(foregroundColor: maroon, side: const BorderSide(color: maroon), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            )),
            const SizedBox(width: 10),
            Expanded(child: ElevatedButton(
              onPressed: availableStock <= 0 || isAdding ? null : () => addToCart(buyNow: true),
              style: ElevatedButton.styleFrom(backgroundColor: maroon, foregroundColor: Colors.white, elevation: 0, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              child: const Text('Buy Now', style: TextStyle(fontWeight: FontWeight.bold)),
            )),
          ]),
        ),
      ),
    );
  }

  Widget _tag(String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(7)),
    child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
  );

  Widget _quantityButton(IconData icon, VoidCallback onPressed) => Material(
    color: const Color(0xFFF9EEEA),
    borderRadius: BorderRadius.circular(9),
    child: InkWell(
      onTap: onPressed,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: const Color(0xFFECDCD4)),
        ),
        child: Icon(icon, size: 18, color: maroon),
      ),
    ),
  );

  Widget _section({required String title, Widget? trailing, required Widget child}) => Container(
    margin: const EdgeInsets.only(top: 10),
    padding: const EdgeInsets.fromLTRB(18, 18, 18, 19),
    color: Colors.white,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(title, style: const TextStyle(color: darkMaroon, fontWeight: FontWeight.w800, fontSize: 16))), if (trailing != null) trailing]),
      const SizedBox(height: 13),
      child,
    ]),
  );
}

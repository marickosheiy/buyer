import 'package:flutter/material.dart';
import '../login_page.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static const Color cream = Color(0xFFFFF8F4);
  static const Color maroon = Color(0xFF963B36);
  static const Color darkMaroon = Color(0xFF721E1E);
  static const Color lightMaroon = Color(0xFFC78F88);
  static const Color fieldColor = Color(0xFFF9EEEA);
  static const Color darkText = Color(0xFF4E3431);

  void _showMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: darkMaroon,
          behavior: SnackBarBehavior.floating,
        ),
      );
  }

  void _showInfoDialog(BuildContext context, String title, String message) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: cream,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: const TextStyle(color: darkMaroon, fontWeight: FontWeight.bold)),
        content: Text(message, style: const TextStyle(color: darkText, height: 1.4)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Got it', style: TextStyle(color: maroon, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmLogout(BuildContext context) async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: cream,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Log out?', style: TextStyle(color: darkMaroon, fontWeight: FontWeight.bold)),
        content: const Text(
          'Are you sure you want to log out of Lumear?',
          style: TextStyle(color: darkText),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel', style: TextStyle(color: lightMaroon)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: ElevatedButton.styleFrom(backgroundColor: maroon, foregroundColor: Colors.white),
            child: const Text('Log Out'),
          ),
        ],
      ),
    );

    if (shouldLogout != true || !context.mounted) return;

    // Removes the dashboard and all previous routes, then opens Login.
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Profile', style: TextStyle(color: darkMaroon, fontSize: 25, fontWeight: FontWeight.bold)),
              const SizedBox(height: 24),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFFFEFEB), cream], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: const Color(0xFFECDCD4)),
                ),
                child: Column(
                  children: [
                    Container(
                      width: 94,
                      height: 94,
                      decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: const Color(0xFFEAD7CE), width: 2)),
                      child: const Icon(Icons.person_rounded, color: maroon, size: 52),
                    ),
                    const SizedBox(height: 13),
                    const Text('Lumear Buyer', style: TextStyle(color: darkMaroon, fontSize: 21, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 5),
                    const Text('buyer@lumear.com', style: TextStyle(color: lightMaroon, fontSize: 13)),
                    const SizedBox(height: 14),
                    OutlinedButton.icon(
                      onPressed: () => _showInfoDialog(context, 'My Account', 'Your profile is using demo information. Account editing can be connected when authentication and database integration are ready.'),
                      icon: const Icon(Icons.edit_outlined, size: 16),
                      label: const Text('Edit Profile'),
                      style: OutlinedButton.styleFrom(foregroundColor: maroon, side: const BorderSide(color: maroon), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 25),
              _sectionTitle('My Shopping'),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFECDCD4))),
                child: Row(
                  children: [
                    _quickLink(Icons.receipt_long_outlined, 'My Orders', () => _showMessage(context, 'Open My Orders from the app navigation.')),
                    _quickLink(Icons.favorite_border_rounded, 'Wishlist', () => _showMessage(context, 'Wishlist will be connected later.')),
                    _quickLink(Icons.confirmation_number_outlined, 'Vouchers', () => _showMessage(context, 'Voucher management is not connected yet.')),
                  ],
                ),
              ),
              const SizedBox(height: 25),
              _sectionTitle('Account'),
              const SizedBox(height: 12),
              _option(context, Icons.person_outline_rounded, 'My Account', 'Manage your personal information', () => _showInfoDialog(context, 'My Account', 'Account editing will be connected when authentication and database integration are ready.')),
              _option(context, Icons.location_on_outlined, 'Addresses', 'Manage your delivery addresses', () => _showInfoDialog(context, 'Addresses', 'Your Address Book is currently available through the checkout flow. We can connect this shortcut directly after checking the app navigation.')),
              _option(context, Icons.payment_outlined, 'Payment Methods', 'Cash on Delivery is the current demo option', () => _showInfoDialog(context, 'Payment Methods', 'Cash on Delivery is currently the supported demo payment method.')),
              const SizedBox(height: 24),
              _sectionTitle('Settings'),
              const SizedBox(height: 12),
              _option(context, Icons.notifications_none_rounded, 'Notification Settings', 'Manage your notification preferences', () => _showInfoDialog(context, 'Notification Settings', 'Notification preferences are a placeholder for now.')),
              _option(context, Icons.settings_outlined, 'App Settings', 'Manage your application preferences', () => _showInfoDialog(context, 'App Settings', 'More app preferences can be added here later.')),
              const SizedBox(height: 24),
              _sectionTitle('Support'),
              const SizedBox(height: 12),
              _option(context, Icons.help_outline_rounded, 'Help Center', 'Get help and support', () => _showInfoDialog(context, 'Help Center', 'Help and support content has not been configured yet.')),
              _option(context, Icons.info_outline_rounded, 'About Lumear', 'Learn more about the application', () => _showInfoDialog(context, 'About Lumear', 'Lumear is a shopping app prototype. Some features are still using demo data.')),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton.icon(
                  onPressed: () => _confirmLogout(context),
                  icon: const Icon(Icons.logout_rounded),
                  label: const Text('Log Out', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  style: OutlinedButton.styleFrom(foregroundColor: maroon, side: const BorderSide(color: maroon), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                ),
              ),
              const SizedBox(height: 12),
              const Center(child: Text('LUMEAR • SHOP WITH EASE', style: TextStyle(color: lightMaroon, fontSize: 10, letterSpacing: 1.4, fontWeight: FontWeight.w600))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _quickLink(IconData icon, String label, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 5),
          child: Column(
            children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(color: fieldColor, borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: maroon, size: 24)),
              const SizedBox(height: 8),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(color: darkText, fontSize: 11, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) => Text(title, style: const TextStyle(color: darkMaroon, fontSize: 16, fontWeight: FontWeight.bold));

  Widget _option(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFECDCD4))),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
        leading: Container(width: 44, height: 44, decoration: BoxDecoration(color: fieldColor, borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: maroon, size: 23)),
        title: Text(title, style: const TextStyle(color: darkText, fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Padding(padding: const EdgeInsets.only(top: 3), child: Text(subtitle, style: const TextStyle(color: lightMaroon, fontSize: 11))),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: lightMaroon, size: 16),
        onTap: onTap,
      ),
    );
  }
}

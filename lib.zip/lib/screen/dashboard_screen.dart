import 'dart:async';
import 'package:flutter/material.dart';
import '../cart_manager.dart';
import '../cart_screen.dart';
import '../product_model.dart';
import '../search_screen.dart';
import 'product_detail_screen.dart';
import 'notifications_screen.dart';
import 'orders_screen.dart';
import 'profile_screen.dart';
import 'voucher_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int selectedIndex = 0;
  static const cream = Color(0xFFFFF8F4);
  static const maroon = Color(0xFF963B36);
  static const muted = Color(0xFFC78F88);
  static const dark = Color(0xFF721E1E);

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: cream,
    body: SafeArea(child: IndexedStack(index: selectedIndex, children: const [
      HomeScreen(), NotificationsScreen(), OrdersScreen(), ProfileScreen(),
    ])),
    bottomNavigationBar: Container(
      decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Color(0xFFECDCD4)))),
      child: SafeArea(top: false, child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _navItem(Icons.home_rounded, 'Home', 0),
          _navItem(Icons.notifications_none_rounded, 'Updates', 1),
          _navItem(Icons.receipt_long_outlined, 'Orders', 2),
          _navItem(Icons.person_outline_rounded, 'Profile', 3),
        ]),
      )),
    ),
  );

  Widget _navItem(IconData icon, String label, int index) {
    final active = selectedIndex == index;
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => setState(() => selectedIndex = index),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 5),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: active ? maroon : muted, size: 24),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: active ? maroon : muted, fontSize: 10, fontWeight: active ? FontWeight.bold : FontWeight.normal)),
        ]),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

String selectedCategory = 'All';
int _bannerIndex = 0;

final List<Map<String, String>> _banners = [
  {
    'tag': 'LUMEAR MEGA SALE',
    'title': 'Big deals.\nLittle prices.',
    'subtitle': 'Discover your next favorite find.',
    'button': 'SHOP NOW',
  },
  {
    'tag': 'NEW ARRIVALS',
    'title': 'Fresh finds,\njust for you.',
    'subtitle': 'Explore something new today.',
    'button': 'EXPLORE NOW',
  },
  {
    'tag': 'LUMEAR SPECIAL',
    'title': 'More finds.\nMore smiles.',
    'subtitle': 'Your next favorite is waiting.',
    'button': 'DISCOVER MORE',
  },
];

class _HomeScreenState extends State<HomeScreen> {
  static const cream = Color(0xFFFFF8F4);
  static const maroon = Color(0xFF963B36);
  static const dark = Color(0xFF721E1E);
  static const muted = Color(0xFFC78F88);
  static const ink = Color(0xFF4E3431);
  String selectedCategory = 'All';
  Timer? _dealTimer;
  int _dealSeconds = 5 * 60 * 60 + 23 * 60 + 45;

  @override
  void initState() {
    super.initState();
    _dealTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _dealSeconds = _dealSeconds > 0 ? _dealSeconds - 1 : 5 * 60 * 60 + 23 * 60 + 45);
    });
  }

  @override
  void dispose() {
    _dealTimer?.cancel();
    super.dispose();
  }

  String get _dealCountdown {
    final h = (_dealSeconds ~/ 3600).toString().padLeft(2, '0');
    final m = ((_dealSeconds % 3600) ~/ 60).toString().padLeft(2, '0');
    final s = (_dealSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }
  final categories = const ['All', 'Fashion', 'Electronics', 'Baby', 'Jewelry', 'Gaming', 'Home', 'Beauty'];

  List<LumearProduct> get visibleProducts {
    if (selectedCategory == 'All') return lumearProducts;
    return lumearProducts.where((p) => p.category == selectedCategory).toList();
  }

  void openProduct(LumearProduct product) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product)));
  }

  @override
  Widget build(BuildContext context) {
    final featured = lumearProducts.where((p) => p.isFeatured).toList();
    return Scaffold(
      backgroundColor: cream,
      body: CustomScrollView(physics: const BouncingScrollPhysics(), slivers: [
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
          child: Row(children: [
            Container(width: 46, height: 46, decoration: const BoxDecoration(color: Color(0xFFF0DCD6), shape: BoxShape.circle), child: const Icon(Icons.shopping_bag_rounded, color: dark)),
            const SizedBox(width: 11),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('GOOD FINDS, BRIGHTER DAYS', style: TextStyle(color: muted, fontSize: 9, letterSpacing: 1.1, fontWeight: FontWeight.bold)),
              SizedBox(height: 3),
              Text('Hello, Lumear Buyer ✨', style: TextStyle(color: dark, fontSize: 18, fontWeight: FontWeight.bold)),
            ])),
            ListenableBuilder(listenable: CartManager.instance, builder: (context, _) {
              final count = CartManager.instance.itemCount;
              return Stack(clipBehavior: Clip.none, children: [
                IconButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
                  icon: const Icon(Icons.shopping_bag_outlined, color: dark, size: 27),
                ),
                if (count > 0) Positioned(right: 0, top: 0, child: AnimatedScale(
                  scale: 1, duration: const Duration(milliseconds: 220),
                  child: Container(padding: const EdgeInsets.all(4), constraints: const BoxConstraints(minWidth: 19, minHeight: 19), decoration: const BoxDecoration(color: maroon, shape: BoxShape.circle), child: Text(count > 99 ? '99+' : '$count', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold))),
                )),
              ]);
            }),
          ]),
        )),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 7, 20, 15),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SearchScreen())),
            child: Container(height: 49, padding: const EdgeInsets.symmetric(horizontal: 15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFEAD7CE))),
              child: const Row(children: [Icon(Icons.search_rounded, color: maroon), SizedBox(width: 10), Expanded(child: Text('Search products, brands, and more', style: TextStyle(color: muted, fontSize: 12))), Icon(Icons.tune_rounded, color: muted, size: 19)])),
          ),
        )),
        
SliverToBoxAdapter(
  child: Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF721E1E),
            Color(0xFF963B36),
            Color(0xFFB45B50),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF721E1E).withOpacity(0.18),
            blurRadius: 16,
            offset: const Offset(0, 7),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'LUMEAR EXCLUSIVE',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Your next\\nfavorite find.',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 27,
                    height: 1.12,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 9),
                const Text(
                  'Discover lovely finds at prices you’ll love.',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 17),
                InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () {
                    setState(() {
                      selectedCategory = 'All';
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 13,
                      vertical: 10,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'SHOP NOW',
                          style: TextStyle(
                            color: Color(0xFF721E1E),
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                        SizedBox(width: 6),
                        Icon(
                          Icons.arrow_forward_rounded,
                          color: Color(0xFF721E1E),
                          size: 14,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 84,
            height: 110,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.12),
              borderRadius: BorderRadius.circular(42),
            ),
            child: const Icon(
              Icons.shopping_bag_rounded,
              color: Colors.white,
              size: 49,
            ),
          ),
        ],
      ),
    ),
  ),
),

        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 25, 20, 12),
          child: _sectionTitle('Shop by category', 'Find your style'),
        )),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 0),
          child: Row(children: [
            Expanded(child: _quickAction(Icons.confirmation_num_outlined, 'Vouchers', 'Rewards', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const VoucherScreen()));
            })),
            const SizedBox(width: 10),
            Expanded(child: _quickAction(Icons.local_shipping_outlined, 'Shipping', 'Demo offers', () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const VoucherScreen()));
            })),
            const SizedBox(width: 10),
            Expanded(child: _quickAction(Icons.local_fire_department_outlined, 'Flash deals', 'Hot picks', () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Flash Deals are right below!')));
            })),
          ]),
        )),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 25, 20, 12),
          child: Row(children: [
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Flash Deals', style: TextStyle(color: dark, fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 3),
              Text('Limited-time demo offers', style: TextStyle(color: muted, fontSize: 10)),
            ])),
            Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), decoration: BoxDecoration(color: dark, borderRadius: BorderRadius.circular(8)),
              child: Text(_dealCountdown, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)))
          ]),
        )),
        SliverToBoxAdapter(child: SizedBox(height: 238, child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          scrollDirection: Axis.horizontal,
          itemCount: lumearProducts.where((p) => p.originalPrice != null).length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, i) {
            final deals = lumearProducts.where((p) => p.originalPrice != null).toList();
            return SizedBox(width: 164, child: _productCard(deals[i], horizontal: true));
          },
        ))),
        SliverToBoxAdapter(child: SizedBox(height: 42, child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          scrollDirection: Axis.horizontal,
          itemCount: categories.length,
          separatorBuilder: (_, __) => const SizedBox(width: 8),
          itemBuilder: (_, i) {
            final selected = selectedCategory == categories[i];
            return ChoiceChip(label: Text(categories[i]), selected: selected,
              onSelected: (_) => setState(() => selectedCategory = categories[i]),
              selectedColor: dark, backgroundColor: Colors.white,
              labelStyle: TextStyle(color: selected ? Colors.white : ink, fontSize: 11, fontWeight: FontWeight.w600),
              side: BorderSide(color: selected ? dark : const Color(0xFFECDCD4)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)));
          },
        ))),
        if (selectedCategory == 'All') ...[
          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 25, 20, 12), child: _sectionTitle('Trending now', 'Popular picks'))),
          SliverToBoxAdapter(child: SizedBox(height: 242, child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            scrollDirection: Axis.horizontal,
            itemCount: featured.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => SizedBox(width: 166, child: _productCard(featured[i], horizontal: true)),
          ))),
        ],
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 25, 20, 12), child: _sectionTitle(selectedCategory == 'All' ? 'Explore products' : selectedCategory, '${visibleProducts.length} items'))),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 13, mainAxisSpacing: 13, childAspectRatio: .57),
            delegate: SliverChildBuilderDelegate((context, index) => _productCard(visibleProducts[index]), childCount: visibleProducts.length),
          ),
        ),
      ]),
    );
  }

  Widget _quickAction(IconData icon, String title, String subtitle, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(14),
    child: Container(
      width: 100,
      height: 82,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFFECDCD4))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: maroon, size: 21),
        const SizedBox(height: 6),
        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: dark, fontSize: 10, fontWeight: FontWeight.bold)),
        Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 8)),
      ]),
    ),
  );

  Widget _sectionTitle(String title, String subtitle) => Row(children: [
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(color: dark, fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 3),
      Text(subtitle, style: const TextStyle(color: muted, fontSize: 10)),
    ])),
    const Icon(Icons.arrow_forward_rounded, color: maroon, size: 19),
  ]);

  Widget _productCard(LumearProduct product, {bool horizontal = false}) {
    return InkWell(
      onTap: () => openProduct(product),
      borderRadius: BorderRadius.circular(17),
      child: Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), border: Border.all(color: const Color(0xFFECDCD4))),
        clipBehavior: Clip.antiAlias,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: 6, child: Stack(fit: StackFit.expand, children: [
            Image.network(product.imageUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: const Color(0xFFF9EEEA), child: Icon(product.icon, size: 45, color: muted))),
            if (product.originalPrice != null) Positioned(top: 9, left: 9, child: Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5), decoration: BoxDecoration(color: maroon, borderRadius: BorderRadius.circular(7)), child: const Text('DEAL', style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)))),
            Positioned(top: 5, right: 5, child: IconButton(
              visualDensity: VisualDensity.compact,
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Wishlist feature coming soon.'))),
              icon: const Icon(Icons.favorite_border_rounded, color: Colors.white, shadows: [Shadow(color: Colors.black54, blurRadius: 5)]),
            )),
          ])),
          Expanded(flex: horizontal ? 5 : 5, child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: ink, fontSize: 12, fontWeight: FontWeight.w600, height: 1.2)),
              const SizedBox(height: 5),
              Row(children: [const Icon(Icons.star_rounded, size: 14, color: Color(0xFFE5A33D)), const SizedBox(width: 3), Text(product.rating.toStringAsFixed(1), style: const TextStyle(color: muted, fontSize: 10)), const SizedBox(width: 6), Expanded(child: Text('${product.soldCount} sold', overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 9)))]),
              const SizedBox(height: 5),
              Text(product.formattedPrice, style: const TextStyle(color: maroon, fontWeight: FontWeight.bold, fontSize: 15)),
              const Spacer(),
              SizedBox(height: 32, width: double.infinity, child: ElevatedButton.icon(
                onPressed: () {
                  if (product.variants.isNotEmpty) {
                    openProduct(product);
                    return;
                  }
                  CartManager.instance.addToCart(productId: product.id, name: product.name, price: product.formattedPrice, icon: product.icon, imageUrl: product.imageUrl);
                  ScaffoldMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(
                    behavior: SnackBarBehavior.floating,
                    duration: const Duration(milliseconds: 1500),
                    backgroundColor: dark,
                    content: Row(children: [const Icon(Icons.check_circle_rounded, color: Colors.white), const SizedBox(width: 8), Expanded(child: Text('${product.name} added to cart'))]),
                    action: SnackBarAction(label: 'CART', textColor: Colors.white, onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen()))),
                  ));
                },
                icon: const Icon(Icons.add_shopping_cart_rounded, size: 14),
                label: Text(product.variants.isEmpty ? 'Add to cart' : 'Choose options', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF2E0DB), foregroundColor: dark, elevation: 0, padding: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9))),
              )),
            ]),
          )),
        ]),
      ),
    );
  }
}

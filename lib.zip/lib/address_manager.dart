import 'package:flutter/foundation.dart';

class SavedAddress {
  String id;
  String label;
  String fullName;
  String phone;
  String region;
  String province;
  String cityMunicipality;
  String barangay;
  String houseStreet;
  bool isDefault;

  SavedAddress({
    required this.id,
    required this.label,
    required this.fullName,
    required this.phone,
    required this.region,
    required this.province,
    required this.cityMunicipality,
    required this.barangay,
    required this.houseStreet,
    this.isDefault = false,
  });

  String get formattedAddress {
    return '$houseStreet, $barangay, $cityMunicipality, $province';
  }

  String get shortAddress {
    return '$cityMunicipality, $province';
  }
}

class AddressManager {
  AddressManager._();

  static final AddressManager instance =
      AddressManager._();

  final ValueNotifier<List<SavedAddress>> addresses =
      ValueNotifier<List<SavedAddress>>([]);

  // ============================================================
  // ADD ADDRESS
  // ============================================================

  void addAddress(SavedAddress address) {
    final current =
        List<SavedAddress>.from(addresses.value);

    // If this address is default,
    // remove default status from all other addresses.
    if (address.isDefault) {
      for (final item in current) {
        item.isDefault = false;
      }
    }

    // First address automatically becomes default.
    if (current.isEmpty) {
      address.isDefault = true;
    }

    current.add(address);

    addresses.value = current;
  }

  // ============================================================
  // UPDATE ADDRESS
  // ============================================================

  void updateAddress(SavedAddress address) {
    final current =
        List<SavedAddress>.from(addresses.value);

    if (address.isDefault) {
      for (final item in current) {
        item.isDefault = false;
      }
    }

    final index = current.indexWhere(
      (item) => item.id == address.id,
    );

    if (index != -1) {
      current[index] = address;
    }

    addresses.value = current;
  }

  // ============================================================
  // DELETE ADDRESS
  // ============================================================

  void deleteAddress(String id) {
    final current =
        List<SavedAddress>.from(addresses.value);

    final wasDefault = current.any(
      (item) =>
          item.id == id &&
          item.isDefault,
    );

    current.removeWhere(
      (item) => item.id == id,
    );

    // If the deleted address was the default,
    // make the first remaining address default.
    if (wasDefault && current.isNotEmpty) {
      current.first.isDefault = true;
    }

    addresses.value = current;
  }

  // ============================================================
  // SET DEFAULT
  // ============================================================

  void setDefault(String id) {
    final current =
        List<SavedAddress>.from(addresses.value);

    for (final item in current) {
      item.isDefault = item.id == id;
    }

    addresses.value = current;
  }

  // ============================================================
  // GET DEFAULT ADDRESS
  // ============================================================

  SavedAddress? get defaultAddress {
    for (final address in addresses.value) {
      if (address.isDefault) {
        return address;
      }
    }

    if (addresses.value.isNotEmpty) {
      return addresses.value.first;
    }

    return null;
  }
}
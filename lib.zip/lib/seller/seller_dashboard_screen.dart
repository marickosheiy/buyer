import 'package:flutter/material.dart';
import 'seller_profile_screen.dart';

class SellerDashboardScreen extends StatefulWidget {
  const SellerDashboardScreen({super.key});

  @override
  State<SellerDashboardScreen> createState() => _SellerDashboardScreenState();
}

class _SellerDashboardScreenState extends State<SellerDashboardScreen> {
  int _selectedIndex = 0;

  static const cream = Color(0xFFFFF8F4);
  static const maroon = Color(0xFF963B36);
  static const darkMaroon = Color(0xFF721E1E);
  static const lightMaroon = Color(0xFFC78F88);
  static const fieldColor = Color(0xFFF9EEEA);
  static const borderColor = Color(0xFFE8CBC0);
  static const darkText = Color(0xFF4E3431);

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const _SellerDashboardBody(),
      const SellerProfileScreen(showBottomNavigation: false),
    ];

    return Scaffold(
      backgroundColor: cream,
      body: SafeArea(
        child: IndexedStack(index: _selectedIndex, children: pages),
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: Colors.white,
        indicatorColor: fieldColor,
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          setState(() => _selectedIndex = index);
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard_rounded),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      ),
    );
  }
}

class _SellerDashboardBody extends StatelessWidget {
  const _SellerDashboardBody();

  static const maroon = Color(0xFF963B36);
  static const darkMaroon = Color(0xFF721E1E);
  static const lightMaroon = Color(0xFFC78F88);
  static const fieldColor = Color(0xFFF9EEEA);
  static const borderColor = Color(0xFFE8CBC0);
  static const darkText = Color(0xFF4E3431);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: maroon,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: const Icon(Icons.storefront_rounded,
                    color: Colors.white, size: 26),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Lumear Seller', style: TextStyle(
                      color: darkMaroon, fontSize: 21,
                      fontWeight: FontWeight.bold)),
                    SizedBox(height: 3),
                    Text('Good day, Seller! ✨',
                        style: TextStyle(color: lightMaroon, fontSize: 13)),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Notifications (demo)',
                onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('No new notifications yet.')),
                ),
                icon: const Icon(Icons.notifications_none_rounded,
                    color: darkMaroon, size: 28),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [maroon, darkMaroon],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.store_mall_directory_outlined,
                    color: Colors.white70, size: 30),
                SizedBox(height: 14),
                Text('Welcome to your shop!', style: TextStyle(
                  color: Colors.white, fontSize: 21,
                  fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text(
                  'Your Lumear seller space is ready. Your shop summary will appear here as you start selling.',
                  style: TextStyle(color: Colors.white, height: 1.45, fontSize: 13),
                ),
              ],
            ),
          ),
          const SizedBox(height: 26),
          const Text('Shop Overview', style: TextStyle(
            color: darkMaroon, fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Row(
            children: [
              Expanded(child: _OverviewCard(
                icon: Icons.inventory_2_outlined, title: 'Products', value: '0')),
              SizedBox(width: 12),
              Expanded(child: _OverviewCard(
                icon: Icons.shopping_bag_outlined, title: 'Orders', value: '0')),
            ],
          ),
          const SizedBox(height: 24),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: borderColor),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Icon(Icons.lightbulb_outline_rounded, color: maroon, size: 23),
                  SizedBox(width: 9),
                  Text('Getting started', style: TextStyle(
                    color: darkMaroon, fontSize: 16, fontWeight: FontWeight.bold)),
                ]),
                SizedBox(height: 10),
                Text(
                  'This is your starter dashboard. Product listings, order handling, and sales features can be added later when you are ready.',
                  style: TextStyle(color: darkText, height: 1.5, fontSize: 13),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const Text('Demo dashboard • Not connected to a database',
              style: TextStyle(color: lightMaroon, fontSize: 11)),
        ],
      ),
    );
  }
}

class _OverviewCard extends StatelessWidget {
  const _OverviewCard({required this.icon, required this.title, required this.value});
  final IconData icon;
  final String title;
  final String value;

  static const maroon = Color(0xFF963B36);
  static const darkMaroon = Color(0xFF721E1E);
  static const fieldColor = Color(0xFFF9EEEA);
  static const borderColor = Color(0xFFE8CBC0);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              color: fieldColor, borderRadius: BorderRadius.circular(13)),
            child: Icon(icon, color: maroon, size: 23),
          ),
          const SizedBox(height: 15),
          Text(value, style: const TextStyle(
            color: darkMaroon, fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 3),
          Text(title, style: const TextStyle(color: darkMaroon, fontSize: 13)),
        ],
      ),
    );
  }
}

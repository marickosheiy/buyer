import 'package:flutter/material.dart';

class SellerProfileScreen extends StatelessWidget {
  const SellerProfileScreen({super.key, this.showBottomNavigation = true});

  final bool showBottomNavigation;

  static const cream = Color(0xFFFFF8F4);
  static const maroon = Color(0xFF963B36);
  static const darkMaroon = Color(0xFF721E1E);
  static const lightMaroon = Color(0xFFC78F88);
  static const fieldColor = Color(0xFFF9EEEA);
  static const borderColor = Color(0xFFE8CBC0);
  static const darkText = Color(0xFF4E3431);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(
        backgroundColor: cream,
        foregroundColor: darkMaroon,
        elevation: 0,
        title: const Text('My Profile',
            style: TextStyle(fontWeight: FontWeight.bold)),
        automaticallyImplyLeading: showBottomNavigation,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          child: Column(
            children: [
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  color: fieldColor, shape: BoxShape.circle,
                  border: Border.all(color: borderColor, width: 1.5)),
                child: const Icon(Icons.person_rounded, size: 54, color: maroon),
              ),
              const SizedBox(height: 14),
              const Text('Seller Name', style: TextStyle(
                color: darkMaroon, fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              const Text('My Lumear Shop',
                  style: TextStyle(color: lightMaroon, fontSize: 14)),
              const SizedBox(height: 22),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: borderColor),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Account', style: TextStyle(
                      color: darkMaroon, fontSize: 16, fontWeight: FontWeight.bold)),
                    SizedBox(height: 14),
                    _ProfileInfoRow(icon: Icons.person_outline_rounded,
                      title: 'Personal information', subtitle: 'Name and account details'),
                    Divider(height: 24, color: borderColor),
                    _ProfileInfoRow(icon: Icons.storefront_outlined,
                      title: 'Shop information', subtitle: 'Shop name and description'),
                    Divider(height: 24, color: borderColor),
                    _ProfileInfoRow(icon: Icons.mail_outline_rounded,
                      title: 'Email address', subtitle: 'Not connected yet'),
                    Divider(height: 24, color: borderColor),
                    _ProfileInfoRow(icon: Icons.phone_outlined,
                      title: 'Mobile number', subtitle: 'Not connected yet'),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity, height: 50,
                child: OutlinedButton.icon(
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text(
                      'Logout will be connected when authentication is added.')),
                  ),
                  icon: const Icon(Icons.logout_rounded),
                  label: const Text('LOG OUT'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: maroon,
                    side: const BorderSide(color: borderColor),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13)),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text('Demo profile • Account details are placeholders',
                textAlign: TextAlign.center,
                style: TextStyle(color: lightMaroon, fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileInfoRow extends StatelessWidget {
  const _ProfileInfoRow({
    required this.icon, required this.title, required this.subtitle,
  });
  final IconData icon;
  final String title;
  final String subtitle;

  static const maroon = Color(0xFF963B36);
  static const darkMaroon = Color(0xFF721E1E);
  static const lightMaroon = Color(0xFFC78F88);
  static const darkText = Color(0xFF4E3431);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: const Color(0xFFF9EEEA),
            borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: maroon, size: 22),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(
                color: darkMaroon, fontWeight: FontWeight.w600, fontSize: 13)),
              const SizedBox(height: 3),
              Text(subtitle, style: const TextStyle(
                color: lightMaroon, fontSize: 11)),
            ],
          ),
        ),
        const Icon(Icons.chevron_right_rounded, color: darkText),
      ],
    );
  }
}

import 'package:flutter/material.dart';

class CartItem {
  final String id;
  final String name;
  final double price;
  final IconData icon;

  // Product information
  final String? imageUrl;

  // Selected variants
  final Map<String, String> selectedVariants;

  // Quantity
  int quantity;

  CartItem({
    required this.id,
    required this.name,
    required this.price,
    required this.icon,
    this.imageUrl,
    this.selectedVariants = const {},
    this.quantity = 1,
  });

  // ==========================================================
  // FORMATTED PRICE
  // ==========================================================

  String get formattedPrice {
    return '₱${price.toStringAsFixed(2)}';
  }

  // ==========================================================
  // TOTAL PRICE
  // ==========================================================

  double get totalPrice {
    return price * quantity;
  }

  String get formattedTotalPrice {
    return '₱${totalPrice.toStringAsFixed(2)}';
  }

  // ==========================================================
  // VARIANT DISPLAY
  // ==========================================================

  String get variantText {
    if (selectedVariants.isEmpty) {
      return '';
    }

    return selectedVariants.entries
        .map(
          (entry) => '${entry.key}: ${entry.value}',
        )
        .join(' • ');
  }
}

// ============================================================
// CART MANAGER
// ============================================================

class CartManager extends ChangeNotifier {
  CartManager._();

  static final CartManager instance = CartManager._();

  final List<CartItem> _items = [];

  // ==========================================================
  // GET ITEMS
  // ==========================================================

  List<CartItem> get items {
    return List.unmodifiable(_items);
  }

  // ==========================================================
  // ITEM COUNT
  // ==========================================================

  int get itemCount {
    int total = 0;

    for (final item in _items) {
      total += item.quantity;
    }

    return total;
  }

  // ==========================================================
  // TOTAL PRICE
  // ==========================================================

  double get totalPrice {
    double total = 0;

    for (final item in _items) {
      total += item.totalPrice;
    }

    return total;
  }

  String get formattedTotalPrice {
    return '₱${totalPrice.toStringAsFixed(2)}';
  }

  // ==========================================================
  // ADD TO CART
  // ==========================================================

  void addToCart({
    required String name,
    required String price,
    required IconData icon,
    String? imageUrl,
    String? productId,
    Map<String, String>? selectedVariants,
    int quantity = 1,
  }) {
    // Convert:
    // "₱499"
    // "₱1,299"
    // "499"
    // "1,299"
    //
    // into a double.

    final cleanedPrice = price
        .replaceAll('₱', '')
        .replaceAll(',', '')
        .trim();

    final parsedPrice =
        double.tryParse(cleanedPrice) ?? 0;

    final actualProductId =
        productId ?? name.toLowerCase();

    final variants =
        selectedVariants ?? {};

    // ========================================================
    // CHECK IF SAME PRODUCT + SAME VARIANT ALREADY EXISTS
    // ========================================================

    final existingIndex = _items.indexWhere(
      (item) {
        return item.id == actualProductId &&
            _mapsAreEqual(
              item.selectedVariants,
              variants,
            );
      },
    );

    if (existingIndex != -1) {
      _items[existingIndex].quantity += quantity;

      notifyListeners();
      return;
    }

    // ========================================================
    // ADD NEW ITEM
    // ========================================================

    _items.add(
      CartItem(
        id: actualProductId,
        name: name,
        price: parsedPrice,
        icon: icon,
        imageUrl: imageUrl,
        selectedVariants: Map<String, String>.from(
          variants,
        ),
        quantity: quantity,
      ),
    );

    notifyListeners();
  }

  // ==========================================================
  // CHECK IF MAPS ARE EQUAL
  // ==========================================================

  bool _mapsAreEqual(
    Map<String, String> first,
    Map<String, String> second,
  ) {
    if (first.length != second.length) {
      return false;
    }

    for (final key in first.keys) {
      if (first[key] != second[key]) {
        return false;
      }
    }

    return true;
  }

  // ==========================================================
  // INCREASE QUANTITY
  // ==========================================================

  void increaseQuantity(int index) {
    if (index < 0 || index >= _items.length) {
      return;
    }

    _items[index].quantity++;

    notifyListeners();
  }

  // ==========================================================
  // DECREASE QUANTITY
  // ==========================================================

  void decreaseQuantity(int index) {
    if (index < 0 || index >= _items.length) {
      return;
    }

    if (_items[index].quantity > 1) {
      _items[index].quantity--;
    } else {
      _items.removeAt(index);
    }

    notifyListeners();
  }

  // ==========================================================
  // SET QUANTITY
  // ==========================================================

  void setQuantity(
    int index,
    int quantity,
  ) {
    if (index < 0 || index >= _items.length) {
      return;
    }

    if (quantity <= 0) {
      _items.removeAt(index);
    } else {
      _items[index].quantity = quantity;
    }

    notifyListeners();
  }

  // ==========================================================
  // REMOVE ITEM
  // ==========================================================

  void removeFromCart(int index) {
    if (index < 0 || index >= _items.length) {
      return;
    }

    _items.removeAt(index);

    notifyListeners();
  }

  // ==========================================================
  // CLEAR CART
  // ==========================================================

  void clearCart() {
    _items.clear();

    notifyListeners();
  }

  // ==========================================================
  // CHECK IF CART IS EMPTY
  // ==========================================================

  bool get isEmpty {
    return _items.isEmpty;
  }

  bool get isNotEmpty {
    return _items.isNotEmpty;
  }
}
import 'package:flutter/material.dart';

import 'address_book_screen.dart';
import 'address_manager.dart';
import 'cart_manager.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  static const Color cream = Color(0xFFFFF8F4);
  static const Color maroon = Color(0xFF963B36);
  static const Color darkMaroon = Color(0xFF721E1E);
  static const Color muted = Color(0xFFC78F88);
  static const Color fieldColor = Color(0xFFF9EEEA);
  static const Color ink = Color(0xFF4E3431);
  static const Color line = Color(0xFFECDCD4);

  SavedAddress? selectedAddress;

  @override
  void initState() {
    super.initState();
    selectedAddress = AddressManager.instance.defaultAddress;
  }

  double get subtotal => CartManager.instance.totalPrice;
  double get shippingFee => subtotal >= 1000 ? 0 : 50;
  double get total => subtotal + shippingFee;

  String money(double value) => '₱${value.toStringAsFixed(2)}';

  Future<void> openAddressBook() async {
    final result = await Navigator.push<SavedAddress?>(
      context,
      MaterialPageRoute(
        builder: (_) => AddressBookScreen(
          selectedAddressId: selectedAddress?.id,
        ),
      ),
    );

    if (!mounted) return;
    setState(() {
      selectedAddress = result ?? AddressManager.instance.defaultAddress;
    });
  }

  void placeOrder() {
    final address = selectedAddress ?? AddressManager.instance.defaultAddress;
    final items = List<CartItem>.from(CartManager.instance.items);

    if (items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Your cart is empty.')),
      );
      return;
    }

    if (address == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please add and select a delivery address.'),
        ),
      );
      return;
    }

    final orderNumber =
        'LUM-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    final orderSubtotal = items.fold<double>(
      0,
      (sum, item) => sum + item.totalPrice,
    );
    final orderShipping = orderSubtotal >= 1000 ? 0.0 : 50.0;
    final orderTotal = orderSubtotal + orderShipping;
    final orderDate = DateTime.now();

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => Dialog(
        backgroundColor: cream,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxHeight: 680),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Column(
                    children: [
                      Container(
                        width: 66,
                        height: 66,
                        decoration: const BoxDecoration(
                          color: Color(0xFFE8F5E9),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check_rounded,
                          color: Colors.green,
                          size: 38,
                        ),
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'Order Confirmed!',
                        style: TextStyle(
                          color: darkMaroon,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'Thank you for shopping with Lumear.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 22),
                _receiptCard(
                  title: 'ORDER DETAILS',
                  children: [
                    _receiptRow('Order number', orderNumber),
                    _receiptRow('Date', _formatDate(orderDate)),
                    _receiptRow('Payment', 'Cash on Delivery'),
                  ],
                ),
                const SizedBox(height: 12),
                _receiptCard(
                  title: 'DELIVERY ADDRESS',
                  children: [
                    Text(
                      address.fullName,
                      style: const TextStyle(
                        color: ink,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(address.phone, style: const TextStyle(color: muted)),
                    const SizedBox(height: 4),
                    Text(
                      address.formattedAddress,
                      style: const TextStyle(color: ink, height: 1.4),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _receiptCard(
                  title: 'PAYMENT SUMMARY',
                  children: [
                    _receiptRow('Subtotal', money(orderSubtotal)),
                    _receiptRow(
                      'Shipping fee',
                      orderShipping == 0 ? 'FREE' : money(orderShipping),
                    ),
                    const Divider(color: line, height: 22),
                    _receiptRow('TOTAL', money(orderTotal), isTotal: true),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      CartManager.instance.clearCart();
                      Navigator.pop(dialogContext);
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: maroon,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(13),
                      ),
                    ),
                    child: const Text(
                      'DONE',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                const Center(
                  child: Text(
                    'Please keep your order details for reference.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: muted, fontSize: 10),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }

  Widget _receiptCard({
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: muted,
              fontSize: 10,
              letterSpacing: 1,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _receiptRow(String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: isTotal ? darkMaroon : muted,
                fontSize: isTotal ? 13 : 11,
                fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: isTotal ? maroon : ink,
                fontSize: isTotal ? 16 : 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(
        backgroundColor: cream,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: darkMaroon),
        ),
        title: const Text(
          'Checkout',
          style: TextStyle(
            color: darkMaroon,
            fontWeight: FontWeight.bold,
            fontSize: 21,
          ),
        ),
      ),
      body: ListenableBuilder(
        listenable: CartManager.instance,
        builder: (context, _) {
          final items = CartManager.instance.items;

          return Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _pageIntro(items.length),
                      const SizedBox(height: 18),
                      _sectionHeading(
                        icon: Icons.location_on_outlined,
                        title: 'Delivery Address',
                        action: 'CHANGE',
                        onAction: openAddressBook,
                      ),
                      const SizedBox(height: 10),
                      _addressCard(),
                      const SizedBox(height: 22),
                      _sectionHeading(
                        icon: Icons.shopping_bag_outlined,
                        title: 'Products Ordered',
                      ),
                      const SizedBox(height: 10),
                      _productsCard(items),
                      const SizedBox(height: 22),
                      _sectionHeading(
                        icon: Icons.confirmation_number_outlined,
                        title: 'Vouchers',
                      ),
                      const SizedBox(height: 10),
                      _voucherCard(),
                      const SizedBox(height: 22),
                      _sectionHeading(
                        icon: Icons.account_balance_wallet_outlined,
                        title: 'Payment Method',
                      ),
                      const SizedBox(height: 10),
                      _paymentCard(),
                      const SizedBox(height: 22),
                      _sectionHeading(
                        icon: Icons.receipt_long_outlined,
                        title: 'Order Summary',
                      ),
                      const SizedBox(height: 10),
                      _summaryCard(),
                      const SizedBox(height: 10),
                      const Center(
                        child: Text(
                          'Please review your order details before placing your order.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: muted, fontSize: 11),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              _bottomPlaceOrder(items.isNotEmpty),
            ],
          );
        },
      ),
    );
  }

  Widget _pageIntro(int itemCount) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFF4E4DE), Color(0xFFFFF8F4)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: line),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.85),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.lock_outline_rounded, color: maroon, size: 25),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Almost yours!',
                  style: TextStyle(
                    color: darkMaroon,
                    fontSize: 17,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$itemCount item${itemCount == 1 ? '' : 's'} in your order · Review everything below.',
                  style: const TextStyle(color: ink, fontSize: 11, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionHeading({
    required IconData icon,
    required String title,
    String? action,
    VoidCallback? onAction,
  }) {
    return Row(
      children: [
        Icon(icon, color: maroon, size: 22),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              color: darkMaroon,
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        if (action != null)
          TextButton(
            onPressed: onAction,
            child: Text(
              action,
              style: const TextStyle(
                color: maroon,
                fontSize: 11,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
      ],
    );
  }

  Widget _addressCard() {
    final address = selectedAddress ?? AddressManager.instance.defaultAddress;

    if (address == null) {
      return _whiteCard(
        child: InkWell(
          onTap: openAddressBook,
          borderRadius: BorderRadius.circular(15),
          child: const Row(
            children: [
              CircleAvatar(
                backgroundColor: fieldColor,
                child: Icon(Icons.add_location_alt_outlined, color: maroon),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Add delivery address',
                      style: TextStyle(
                        color: darkMaroon,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Add your recipient details and full address.',
                      style: TextStyle(color: muted, fontSize: 11),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: muted),
            ],
          ),
        ),
      );
    }

    return _whiteCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.location_on_rounded, color: maroon, size: 24),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      spacing: 7,
                      runSpacing: 5,
                      children: [
                        Text(
                          address.fullName,
                          style: const TextStyle(
                            color: ink,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 7,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: fieldColor,
                            borderRadius: BorderRadius.circular(5),
                          ),
                          child: Text(
                            address.label,
                            style: const TextStyle(
                              color: maroon,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      address.phone,
                      style: const TextStyle(color: muted, fontSize: 12),
                    ),
                    const SizedBox(height: 9),
                    Text(
                      address.formattedAddress,
                      style: const TextStyle(
                        color: ink,
                        fontSize: 12,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Edit address',
                onPressed: openAddressBook,
                icon: const Icon(Icons.edit_outlined, color: maroon, size: 19),
              ),
            ],
          ),
          const SizedBox(height: 13),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: openAddressBook,
              style: OutlinedButton.styleFrom(
                foregroundColor: maroon,
                side: const BorderSide(color: line),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text(
                'CHANGE DELIVERY ADDRESS',
                style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _productsCard(List<CartItem> items) {
    return _whiteCard(
      child: items.isEmpty
          ? const Padding(
              padding: EdgeInsets.all(12),
              child: Center(
                child: Text(
                  'Your cart is empty.',
                  style: TextStyle(color: muted),
                ),
              ),
            )
          : Column(
              children: [
                for (var i = 0; i < items.length; i++) ...[
                  if (i > 0) const Divider(color: line, height: 22),
                  _productRow(items[i]),
                ],
                const Divider(color: line, height: 22),
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Items subtotal',
                        style: TextStyle(color: muted, fontSize: 12),
                      ),
                    ),
                    Text(
                      money(subtotal),
                      style: const TextStyle(
                        color: maroon,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ],
            ),
    );
  }

  Widget _productRow(CartItem item) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 76,
            height: 82,
            color: fieldColor,
            child: item.imageUrl != null && item.imageUrl!.isNotEmpty
                ? Image.network(
                    item.imageUrl!,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        Icon(item.icon, color: muted, size: 32),
                  )
                : Icon(item.icon, color: muted, size: 32),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: ink,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                  height: 1.3,
                ),
              ),
              if (item.variantText.isNotEmpty) ...[
                const SizedBox(height: 5),
                Text(
                  item.variantText,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: muted, fontSize: 10),
                ),
              ],
              const SizedBox(height: 6),
              Text(
                '${money(item.price)} × ${item.quantity}',
                style: const TextStyle(color: muted, fontSize: 11),
              ),
              const SizedBox(height: 6),
              Text(
                money(item.totalPrice),
                style: const TextStyle(
                  color: maroon,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _voucherCard() {
    return _whiteCard(
      child: InkWell(
        onTap: () {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Voucher selection will be connected in a future update.'),
            ),
          );
        },
        borderRadius: BorderRadius.circular(14),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: fieldColor,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.local_offer_outlined, color: maroon),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Apply a voucher',
                    style: TextStyle(
                      color: ink,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Choose an available discount or shipping voucher.',
                    style: TextStyle(color: muted, fontSize: 11, height: 1.4),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: muted),
          ],
        ),
      ),
    );
  }

  Widget _paymentCard() {
    return _whiteCard(
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: fieldColor,
              borderRadius: BorderRadius.circular(13),
            ),
            child: const Icon(Icons.payments_outlined, color: maroon, size: 25),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Cash on Delivery (COD)',
                  style: TextStyle(
                    color: ink,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Pay when your order arrives.',
                  style: TextStyle(color: muted, fontSize: 11),
                ),
              ],
            ),
          ),
          const Icon(Icons.check_circle_rounded, color: maroon, size: 23),
        ],
      ),
    );
  }

  Widget _summaryCard() {
    return _whiteCard(
      child: Column(
        children: [
          _summaryRow('Subtotal', money(subtotal)),
          const SizedBox(height: 13),
          _summaryRow(
            'Shipping fee',
            shippingFee == 0 ? 'FREE' : money(shippingFee),
            valueColor: shippingFee == 0 ? Colors.green.shade700 : ink,
          ),
          const SizedBox(height: 13),
          if (shippingFee == 0)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 13),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF5E9),
                borderRadius: BorderRadius.circular(9),
              ),
              child: const Row(
                children: [
                  Icon(Icons.check_circle_outline, color: Colors.green, size: 17),
                  SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      'You unlocked free shipping!',
                      style: TextStyle(color: Color(0xFF367A3B), fontSize: 11),
                    ),
                  ),
                ],
              ),
            ),
          const Divider(color: line, height: 22),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Total Payment',
                  style: TextStyle(
                    color: darkMaroon,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),
                ),
              ),
              Text(
                money(total),
                style: const TextStyle(
                  color: maroon,
                  fontWeight: FontWeight.bold,
                  fontSize: 22,
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Shipping is free for orders of ₱1,000 or more.',
              style: TextStyle(color: muted, fontSize: 10),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(
    String label,
    String value, {
    Color valueColor = ink,
  }) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(color: muted, fontSize: 12),
          ),
        ),
        Text(
          value,
          style: TextStyle(
            color: valueColor,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Widget _whiteCard({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: line),
        boxShadow: [
          BoxShadow(
            color: darkMaroon.withValues(alpha: 0.025),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _bottomPlaceOrder(bool enabled) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: line)),
        boxShadow: [
          BoxShadow(
            color: Color(0x0D721E1E),
            blurRadius: 12,
            offset: Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Total Payment',
                    style: TextStyle(color: muted, fontSize: 10),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    money(total),
                    style: const TextStyle(
                      color: maroon,
                      fontWeight: FontWeight.bold,
                      fontSize: 19,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: enabled ? placeOrder : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: maroon,
                    disabledBackgroundColor: muted,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(13),
                    ),
                  ),
                  child: const Text(
                    'PLACE ORDER',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

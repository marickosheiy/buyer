import 'package:flutter/material.dart';
import 'product_model.dart';
import 'screen/product_detail_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  static const cream = Color(0xFFFFF8F4);
  static const maroon = Color(0xFF963B36);
  static const dark = Color(0xFF721E1E);
  static const muted = Color(0xFFC78F88);
  final controller = TextEditingController();
  String category = 'All';
  String sortBy = 'Recommended';

  List<LumearProduct> get results {
    final q = controller.text.trim().toLowerCase();
    final found = lumearProducts.where((p) {
      final matchesText = q.isEmpty || p.name.toLowerCase().contains(q) || p.category.toLowerCase().contains(q) || p.shopName.toLowerCase().contains(q);
      final matchesCategory = category == 'All' || p.category == category;
      return matchesText && matchesCategory;
    }).toList();

    if (sortBy == 'Price: Low to High') {
      found.sort((a, b) => a.price.compareTo(b.price));
    } else if (sortBy == 'Price: High to Low') {
      found.sort((a, b) => b.price.compareTo(a.price));
    } else if (sortBy == 'Top Rated') {
      found.sort((a, b) => b.rating.compareTo(a.rating));
    } else if (sortBy == 'Best Selling') {
      found.sort((a, b) => b.soldCount.compareTo(a.soldCount));
    }
    return found;
  }

  @override
  void dispose() { controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final found = results;
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(backgroundColor: cream, elevation: 0, iconTheme: const IconThemeData(color: dark), title: const Text('Find your next favorite', style: TextStyle(color: dark, fontSize: 18, fontWeight: FontWeight.bold))),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 5, 16, 12), child: TextField(
          controller: controller,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: 'Search products or categories',
            prefixIcon: const Icon(Icons.search_rounded, color: maroon),
            suffixIcon: controller.text.isEmpty ? null : IconButton(onPressed: () { controller.clear(); setState(() {}); }, icon: const Icon(Icons.close_rounded)),
            filled: true, fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFECDCD4))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: Color(0xFFECDCD4))),
          ),
        )),
        SizedBox(height: 39, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
          for (final c in const ['All', 'Fashion', 'Electronics', 'Baby', 'Jewelry', 'Gaming', 'Home', 'Beauty'])
            Padding(padding: const EdgeInsets.only(right: 7), child: ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c), selectedColor: dark, labelStyle: TextStyle(color: category == c ? Colors.white : dark, fontSize: 11), backgroundColor: Colors.white, side: const BorderSide(color: Color(0xFFECDCD4)))),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(18, 13, 12, 8), child: Row(children: [
          const Expanded(child: Text('Products', style: TextStyle(color: dark, fontWeight: FontWeight.bold, fontSize: 16))),
          Text('${found.length} found', style: const TextStyle(color: muted, fontSize: 11)),
          const SizedBox(width: 8),
          PopupMenuButton<String>(
            tooltip: 'Sort products',
            icon: const Icon(Icons.sort_rounded, color: maroon),
            onSelected: (value) => setState(() => sortBy = value),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'Recommended', child: Text('Recommended')),
              PopupMenuItem(value: 'Price: Low to High', child: Text('Price: Low to High')),
              PopupMenuItem(value: 'Price: High to Low', child: Text('Price: High to Low')),
              PopupMenuItem(value: 'Top Rated', child: Text('Top Rated')),
              PopupMenuItem(value: 'Best Selling', child: Text('Best Selling')),
            ],
          ),
        ])),
        Expanded(child: found.isEmpty
          ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.search_off_rounded, size: 55, color: muted), SizedBox(height: 10), Text('No products found', style: TextStyle(color: dark, fontWeight: FontWeight.bold)), SizedBox(height: 5), Text('Try another name or category.', style: TextStyle(color: muted, fontSize: 12))]))
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .64),
              itemCount: found.length,
              itemBuilder: (_, i) {
                final p = found[i];
                return InkWell(
                  borderRadius: BorderRadius.circular(15),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailScreen(product: p))),
                  child: Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFFECDCD4))), clipBehavior: Clip.antiAlias,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Expanded(child: Image.network(p.imageUrl, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Center(child: Icon(p.icon, size: 40, color: muted)))),
                      Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF4E3431), fontSize: 12, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 5),
                        Row(children: [const Icon(Icons.star_rounded, color: Color(0xFFE5A33D), size: 14), const SizedBox(width: 3), Text('${p.rating} · ${p.soldCount} sold', style: const TextStyle(color: muted, fontSize: 9))]),
                        const SizedBox(height: 5),
                        Text(p.formattedPrice, style: const TextStyle(color: maroon, fontWeight: FontWeight.bold, fontSize: 14)),
                      ])),
                    ]),
                  ),
                );
              },
            )),
      ]),
    );
  }
}
